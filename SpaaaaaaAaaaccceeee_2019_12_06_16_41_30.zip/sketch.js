var planets = [];

function setup() {
  createCanvas(400, 400, WEBGL);
  ellipseMode(CENTER);
  let c = color(51, 0, 102);
  fill(c);
  background(c);
  for (var i = 0; i < 9; i++) {
    var planet = {
      x: 90,
      y: 20,
      r: 0.01,
      color: 0,
    }
    planets.push(planet);
  }
}

function draw() {
  for (var i = 0; i < 9; i++) {
    var currentPlanet = planets[i];
    currentPlanet.x += random(-2.5, 2.5);
       currentPlanet.y += random(-2.5, 2.5);
    fill("green");
    rotateX(frameCount * 0.01);
  rotateZ(frameCount * 0.01);
  sphere(20)
  }
}