  function setup() {
    createCanvas(innerWidth, innerHeight, WEBGL);
    angleMode(DEGREES);
  }

  function draw() {
noStroke();
    background(220);
    background(0);
    push();
    rotateY(frameCount / 2);
    translate(0, 0, 0);

    // Sun
    fill("yellow");
    sphere(25);
//Mercury 
     translate(40, 0, 0);
    push();
    rotateY(frameCount * 4);
    rotateX(frameCount * 6);
    fill("grey");
    sphere(3);
    translate(15, 0, 0);
    fill("grey");
    sphere(2);
    pop();
    // Venus 
        translate(33, 0, 0);
    push();
    rotateY(frameCount * 4);
    rotateX(frameCount * 6);
    fill("orange");
    sphere(3);
    translate(22, 0, 0);
    fill("orange");
    sphere(2);
    pop();
    
    // Earth
    translate(35, 0, 0);
    push();
    rotateY(frameCount * 4);
    rotateX(frameCount * 6);
    fill("blue");
    sphere(5);
    translate(18, 0, 0);
    fill("blue");
    sphere(2);
    pop();

    // Mars

    translate(40, 0, 0);
    push();
    rotateY(frameCount * 4)
    rotateX(frameCount * 6)
    fill("red")
    sphere(7);
    translate(20, 0, 0);
    fill("red")
    sphere(3)
    pop();
    //jupiter
  
    translate(43, 0, 0);
    push();
    rotateY(frameCount * 4)
    rotateX(frameCount * 6)
    fill("brown")
    sphere(7);
    translate(22, 0, 0);
    fill("brown")
    sphere(3)
    pop();
// saturn
    translate(45,0,0);
    push();
    rotateY(frameCount *4)
    rotateX(frameCount * 6)
    fill(255,204,0)
    sphere(10);
    translate(23,0,0);
    fill(255,204,0)
    sphere(5);
    pop();
    
    //uranus
    translate(50,0,0);
    push();
    rotateY(frameCount *4)
    rotateX(frameCount * 6)
    fill("green")
    sphere(12);
    translate(25,0,0);
    fill("green")
    sphere(6);
    pop();
    //neptune 
       translate(55,0,0);
    push();
    rotateY(frameCount *4)
    rotateX(frameCount * 6)
    fill(50,55,100)
    sphere(12);
    translate(28,0,0);
    fill(50,52,100)
    sphere(6);
    pop();
  }