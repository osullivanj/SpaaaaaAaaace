function setup() {
  createCanvas(innerWidth, innerHeight, WEBGL);
  angleMode(DEGREES);
}

function draw() {
  noStroke();
  background(220);
  background(0);
  push();
  rotateY(frameCount / 2);
  translate(0, 0, 0);


  // Sun
  
  fill("yellow");
  sphere(25);
  //Mercury 
  translate(40, 0, 0);
  push();
  rotateY(frameCount * 4);
  rotateX(frameCount * 6);
  fill(102, 0, 204);
  sphere(3);
  translate(15, 0, 0);
  fill(102, 0, 204);
  sphere(2);
  pop();


  // Venus 
  
  translate(33, 0, 0);
  push();
  rotateY(frameCount * 4);
  rotateX(frameCount * 6);
  fill(255, 153, 51);
  sphere(3);
  translate(22, 0, 0);
  fill(255, 153, 51);
  sphere(2);
  pop();

  // Earth
 
  translate(35, 0, 0);
  push();
  rotateY(frameCount * 4);
  rotateX(frameCount * 6);
  fill("blue");
  sphere(5);
  translate(18, 0, 0);
  fill("blue");
  sphere(2);
  pop();

  // Mars

  translate(40, 0, 0);
  push();
  rotateY(frameCount * 4)
  rotateX(frameCount * 6)
  fill("red")
  sphere(7);
  translate(20, 0, 0);
  fill("red")
  sphere(3)
  pop();
  //jupiter

  translate(43, 0, 0);
  push();
  rotateY(frameCount * 4)
  rotateX(frameCount * 6)
  fill(51, 25, 0)
  sphere(7);
  translate(22, 0, 0);
  fill(51, 25, 0)
  sphere(3)
  pop();
  // saturn
  translate(45, 0, 0);
  push();
  rotateY(frameCount * 4)
  rotateX(frameCount * 6)
  fill(153, 153, 0)
  sphere(10);
  translate(23, 0, 0);
  fill(153, 153, 0)
  sphere(5);
  pop();

  //uranus
  translate(50, 0, 0);
  push();
  rotateY(frameCount * 4)
  rotateX(frameCount * 6)
  fill(0, 255, 255)
  sphere(12);
  translate(25, 0, 0);
  fill(0, 255, 255)
  sphere(6);
  pop();
  //neptune 
  translate(55, 0, 0);
  push();
  rotateY(frameCount * 4)
  rotateX(frameCount * 6)
  fill(102, 102, 255)
  sphere(12);
  translate(28, 0, 0);
  fill(102, 102, 255)
  sphere(6);
  pop();
  // pluto
  translate(100, 0, 0);
  push();
  rotateY(frameCount * 4)
  rotateX(frameCount * 4)
  fill(160, 160, 160)
  sphere(4);
  translate(28, 0, 0);
  fill(160, 160, 160)
  sphere(2);
  pop();
}