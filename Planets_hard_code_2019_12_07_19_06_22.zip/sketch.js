  function setup() {
    createCanvas(innerWidth, innerHeight, WEBGL);
    angleMode(DEGREES);
  }

  function draw() {

    background(220);

    push();
    rotateY(frameCount / 2);
    translate(0, 0, 0);

    // Sun
    fill("yellow");
    sphere(60);
//Mercury 
     translate(300, 0, 0);
    push();
    rotateY(frameCount * 4);
    rotateX(frameCount * 6);
    fill("orange");
    sphere(10);
    translate(50, 0, 0);
    fill("orange");
    sphere(4);
    pop();
    
    // Earth
    translate(300, 0, 0);
    push();
    rotateY(frameCount * 4);
    rotateX(frameCount * 6);
    fill("blue");
    sphere(15);
    translate(50, 0, 0);
    fill("blue");
    sphere(7);
    pop();

    // Mars

    translate(300, 0, 0);
    push();
    rotateY(frameCount * 4)
    rotateX(frameCount * 6)
    fill("red")
    sphere(10);
    translate(50, 0, 0);
    fill("red")
    sphere(3)
    pop();
// saturn
    translate(300,0,0);
    push();
    rotateY(frameCount *4)
    rotateX(frameCount * 6)
    fill(255,204,0)
    sphere(40);
    translate(50,0,0);
    fill(255,204,0)
    sphere(10);
    pop();
    
    //uranus
    translate(300,0,0);
    push();
    rotateY(frameCount *4)
    rotateX(frameCount * 6)
    fill("green")
    sphere(30);
    translate(50,0,0);
    fill("green")
    sphere(10);
    pop();
  }